# TDT-ETF Exit V2.3.4-Market Integrated

Author: Dr. Yen

## Overview

This repository contains the GitHub / Codex-ready specification files for:

**TDT-ETF Exit V2.3.4-Market Integrated**

Chinese Name:
0052, 00830 ETF 大盤整合風控出場模型

English Name:
Taiwan ETF Exit Risk Control Model V2.3.4 with TDT-RM Market Layer

Version Status:
Spec Freeze Candidate / Historical Stress-Test Ready

Generated Time:
2026-05-24 15:55

Applicable Assets:
- 0052
- 00830

## Purpose

This is an ETF risk-control and exit model. It is used after market close or the following morning to evaluate whether 0052 and 00830 should be:

- HOLD
- STOP_ADD
- REDUCE
- HEAVY_REDUCE
- EXIT

This model is not a buy model, not an averaging-down model, and not a short-term forecasting model.

## Specification Structure

- `spec/01_Model_Positioning.md`
- `spec/02_Market_Layer.md`
- `spec/03_E1_ETF_Structure.md`
- `spec/04_E2_Volume_Candlestick.md`
- `spec/05_E3_Market_Risk.md`
- `spec/06_E4_Theme_Breakdown.md`
- `spec/07_Hard_Red.md`
- `spec/08_EVENT_RED_LOCK.md`
- `spec/09_PHR_LOCK.md`
- `spec/10_SBRL_LOCK.md`
- `spec/11_Market_Floor_and_Warnings.md`
- `spec/12_Final_Signal_Engine.md`
- `spec/13_Daily_Report_Format.md`
- `spec/14_Stress_Test_Plan.md`

## Development Notes

The core development logic should treat:

- E1-E4 as scoring engines
- Hard Red as the only mandatory EXIT engine
- EVENT_RED_LOCK, PHR_LOCK, and SBRL_LOCK as stateful lock mechanisms
- MARKET_FLOOR and MARKET_FLOOR_RED as final signal floors
- MHS, BCD, Tail Risk, and Crash Probability as risk context or warning layers, not standalone EXIT triggers
