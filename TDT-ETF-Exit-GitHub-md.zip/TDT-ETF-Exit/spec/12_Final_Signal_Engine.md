# 12 Final Signal Engine

## E_TOTAL Formula

```text
E_TOTAL = E1 + E2 + E3 + E4
```

## score_signal Mapping

```text
IF E_TOTAL >= 0 AND E_TOTAL <= 4:
    score_signal = GREEN
    score_action = HOLD
```

```text
IF E_TOTAL >= 5 AND E_TOTAL <= 7:
    score_signal = YELLOW
    score_action = STOP_ADD
```

```text
IF E_TOTAL >= 8 AND E_TOTAL <= 10:
    score_signal = ORANGE
    score_action = REDUCE
```

```text
IF E_TOTAL >= 11 AND E_TOTAL <= 13:
    score_signal = ORANGE_ENHANCED
    score_action = HEAVY_REDUCE
```

```text
IF E_TOTAL >= 14 AND E_TOTAL <= 16:
    score_signal = SCORE_RED
    score_action = HEAVY_REDUCE
    check Hard Red
```

```text
IF Hard_Red == TRUE:
    final_signal = RED
    final_action = EXIT
```

## score_signal vs final_signal

score_signal is the raw score signal.

final_signal is the final signal after applying:
- Hard Red
- EVENT_RED_LOCK
- PHR_LOCK
- SBRL_LOCK
- MARKET_FLOOR
- MARKET_FLOOR_RED
- MHS / BCD / Tail Risk warning rules

Daily operation uses final_signal.

## Final Signal Composition Order

1. Calculate E1, E2, E3, and E4.
2. Calculate E_TOTAL.
3. Generate raw score_signal according to score_signal mapping.
4. Check Hard Red.
5. Check EVENT_RED_LOCK.
6. Check PHR_LOCK.
7. Check SBRL_LOCK.
8. Apply MARKET_FLOOR.
9. Apply MARKET_FLOOR_RED.
10. Apply MHS / BCD / Tail Risk warning rules.
11. Output final_signal and final_action.

## Step 4 - Hard Red

```text
IF any(HR1, HR2, HR3, HR4, HR5, HR6) == TRUE:
    final_signal = RED
    final_action = EXIT
```

## Step 5 - EVENT_RED_LOCK

```text
IF EVENT_RED_LOCK == TRUE:
    final_signal >= ORANGE_ENHANCED
```

## Step 6 - PHR_LOCK

```text
IF PHR_LOCK == TRUE:
    final_signal >= ORANGE_ENHANCED
```

If Hard Red is triggered again during PHR_LOCK:

```text
PHR_count = 0
wait until new Hard Red resolves
restart PHR_LOCK
```

## Step 7 - SBRL_LOCK

```text
IF SBRL_LOCK == TRUE:
    final_signal >= ORANGE
```

## Step 8 - MARKET_FLOOR

```text
IF TDT_RM_signal == ORANGE:
    final_signal >= YELLOW
```

## Step 9 - MARKET_FLOOR_RED

```text
IF TDT_RM_signal == RED:
    final_signal >= ORANGE
```

## Step 10 - MHS / BCD / Tail Risk Warning Rules

If these warning indicators trigger alone:

```text
final_signal <= YELLOW_ENHANCED
```

If:

```text
MHS >= 86
AND BCD >= 61
AND TCWRS >= 41
AND ETI5 >= 2:
    final_signal <= ORANGE
```

These warning rules must not independently upgrade to:
- Orange Enhanced
- Red
- EXIT

## final_signal to final_action Mapping

### Green

```text
final_signal = GREEN
final_action = HOLD
```

Normal holding.

### Yellow

```text
final_signal = YELLOW
final_action = STOP_ADD
```

Hold, do not chase, do not add, do not use leverage.

### Orange

```text
final_signal = ORANGE
final_action = REDUCE
```

Reduce partial exposure, prioritizing weak or higher-risk positions.

### Orange Enhanced

```text
final_signal = ORANGE_ENHANCED
final_action = HEAVY_REDUCE
```

Actively reduce ETF exposure to avoid further market deterioration.

### Red

```text
final_signal = RED
final_action = EXIT
```

Use only when Hard Red is active.
