# 05 E3 Market System Risk

## Score Range

```text
0, 1, 2, 4
```

## Source

TDT-RM V5.1.3 Rev.3 Final Freeze market signal.

## Scoring Rules

```text
IF TDT_RM_signal == GREEN:
    E3 = 0
```

```text
IF TDT_RM_signal == YELLOW:
    E3 = 1
```

```text
IF TDT_RM_signal == YELLOW_ENHANCED:
    E3 = 1
```

```text
IF TDT_RM_signal == ORANGE:
    E3 = 2
```

```text
IF TDT_RM_signal == RED:
    E3 = 4
```

## Invalid Values

E3 does not use:
- 3
- 1.5

## Meaning of E3 = 4

E3 = 4 represents confirmed market system risk.

It is a core condition for:
- HR4
- HR5
- HR6

## EXIT Restriction

E3 = 4 does not independently trigger EXIT.

It must be paired with at least one of:
- ETF breakdown
- Theme breakdown
- Macro Shock
- High-score resonance

## Design Explanation

E3 is the market system risk score inside the ETF model.

It does not fully duplicate every detail of TDT-RM.

Yellow and Yellow Enhanced both imply that market structural failure has not yet been confirmed, so both use:

```text
E3 = 1
```

Market signal reaching Orange or Red creates meaningful ETF score deterioration.

Yellow Enhanced differences are handled in daily report text, action language, stop adding, and leverage reduction, not through higher E3 scoring.
