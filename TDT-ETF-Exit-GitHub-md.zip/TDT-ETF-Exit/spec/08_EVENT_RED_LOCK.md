# 08 EVENT_RED_LOCK

## Purpose

When ETF and theme structure both break down over the medium term, EVENT_RED_LOCK prevents a one-day rebound from being misclassified as repair.

## 0052 Dual-Axis Event Trigger Conditions

All conditions required:

```text
IF 0052_Close < 0052_MA60
AND TSMC_Close < TSMC_MA60
AND count(0052_technology_leaders_below_MA20) >= 4 of 6:
    dual_axis_event = TRUE
```

## 00830 Dual-Axis Event Trigger Conditions

All conditions required:

```text
IF 00830_Close < 00830_MA60
AND SOX_Close < SOX_MA60:
    dual_axis_event = TRUE
```

## EVENT_RED_LOCK Activation

```text
IF dual_axis_event == TRUE:
    EVENT_RED_LOCK = TRUE
    EVENT_D0 = current_date
    EVENT_RED_LOCK_start_date = EVENT_D0
```

## Lock Floor

```text
IF EVENT_RED_LOCK == TRUE:
    final_signal >= ORANGE_ENHANCED
```

## 0052 EVENT_RED_LOCK Release Conditions

All conditions required:

1. 0052 closes above MA60 for 2 consecutive evaluable trading days.
2. TSMC closes above MA60 for 2 consecutive evaluable trading days.
3. 0052 does not show explosive black candle during the period.
4. TSMC does not show theme explosive black candle during the period.
5. Fewer than 4 of 6 technology leaders are below MA20.
6. Data is complete, with no market closure or major missing data.

## 00830 EVENT_RED_LOCK Release Conditions

All conditions required:

1. 00830 closes above MA60 for 2 consecutive evaluable trading days.
2. SOX closes above MA60 for 2 consecutive evaluable trading days.
3. 00830 does not show explosive black candle during the period.
4. SOX does not show theme explosive black candle during the period.
5. No SOX_DATA_LAG.
6. 00830 does not use the 0052 six technology leaders condition.

## Evaluable Trading Day Definition

A trading day is evaluable only if:

1. ETF closing data is complete.
2. Theme closing data is complete.
3. No market closure.
4. No data missing.
5. For 00830, day must not be under SOX_DATA_LAG.
6. Missing data days cannot count toward release conditions.
