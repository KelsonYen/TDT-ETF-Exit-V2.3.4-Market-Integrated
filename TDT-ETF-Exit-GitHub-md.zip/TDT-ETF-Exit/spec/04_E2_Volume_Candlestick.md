# 04 E2 Volume and Candlestick Breakdown

## Score Range

```text
0-4
```

## Purpose

Evaluate whether the ETF shows:
- Volume-price loss of control
- Explosive long black candle
- High-level reversal

## Official Evaluation Order

### Rule 1 - Explosive Black Candle + Next Day Failed to Recover MA20

```text
IF explosive_black_candle == TRUE
AND next_day_close < MA20:
    E2 = 4
    STOP all other E2 calculations
```

### Rule 2 - Explosive Black Candle

```text
IF explosive_black_candle == TRUE:
    E2 = 3
    STOP all other E2 calculations
```

### Rule 3 - Normal Components

Only calculate normal components if Rule 1 and Rule 2 are not triggered.

## Normal Components

```text
score = 0
```

### Daily Loss

```text
IF daily_return <= -3%:
    score += 1
```

### Volume Score

```text
IF volume >= 20_day_avg_volume * 1.80:
    volume_score = 1
```

```text
IF volume >= 20_day_avg_volume * 2.20 AND close < open:
    volume_score = 2
```

Volume score uses layered highest score only.

Do not accumulate 180% and 220% conditions.

### Black Candle Body

```text
IF black_body_size >= daily_range * 0.60:
    score += 1
```

### High-Level Upper Shadow

```text
IF high_level_upper_shadow == TRUE:
    score += 1
```

## Normal Component Cap

```text
E2 = min(score + volume_score, 3)
```

Normal component maximum is 3.

## Explosive Black Candle Override

If explosive black candle is true:

```text
E2 = 3
```

Discard:
- Daily loss score
- Volume score
- Black candle body score
- High-level upper shadow score

## Explosive Black Candle + Failed MA20 Recovery Override

If explosive black candle and next-day failed MA20 recovery are both true:

```text
E2 = 4
```

Discard all other sub-scores.

## Candlestick Definitions

### High Level

```text
IF ETF_Close >= 0.95 * highest_close_last_60_days:
    high_level = TRUE
```

OR

```text
IF ETF_Close >= ETF_MA60 * 1.10:
    high_level = TRUE
```

### Long Black Candle

```text
IF daily_return <= -3%
AND black_body_size >= daily_range * 0.60:
    long_black_candle = TRUE
```

### Explosive Volume

```text
IF volume >= 20_day_avg_volume * 1.80:
    explosive_volume = TRUE
```

### Extreme Explosive Volume

```text
IF volume >= 20_day_avg_volume * 2.20:
    extreme_explosive_volume = TRUE
```

### Explosive Black Candle

All conditions required:

```text
IF daily_return <= -3%
AND volume >= 20_day_avg_volume * 1.80
AND black_body_size >= daily_range * 0.60:
    explosive_black_candle = TRUE
```

### High-Level Upper Shadow

All conditions required:

1. High level
2. Upper shadow >= 40% of daily range
3. Close failed to recover upper 70% of daily range
4. Volume >= 150% of 20-day average volume

Formula:

```text
close < low + 0.7 * (high - low)
```
