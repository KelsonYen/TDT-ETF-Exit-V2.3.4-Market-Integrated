# 07 Hard Red Engine

## Purpose

Hard Red is the mandatory EXIT engine.

Only Hard Red can force:

```text
final_signal = RED
final_action = EXIT
```

## HR1

Condition:

```text
IF TDT_RM_signal == RED
AND ETF_Close < ETF_MA20:
    Hard_Red = TRUE
    final_action = EXIT
```

## HR2

Condition:

```text
IF TDT_RM_signal == RED
AND ETF_Close < ETF_MA60
AND Theme_Close < Theme_MA60:
    Hard_Red = TRUE
    final_action = EXIT
```

## HR3

Condition:

```text
IF ETF_explosive_black_candle == TRUE
AND ETF_next_day_close < ETF_MA20
AND (T_day_TDT_RM_signal == RED OR T_plus_1_day_TDT_RM_signal == RED):
    Hard_Red = TRUE
    final_action = EXIT
```

Supplement:

If market becomes Red after T+2 and ETF remains below MA20, HR1 takes over.

## HR4

Condition:

```text
IF E1 == 4
AND E4 == 4
AND E3 == 4:
    Hard_Red = TRUE
    final_action = EXIT
```

## HR5 - Macro Shock

Condition:

```text
IF E3 == 4
AND (market_daily_loss >= 5% OR market_2_day_loss >= 7%)
AND ETF_Close < ETF_MA20
AND Theme_Close < Theme_MA20:
    Hard_Red = TRUE
    final_action = EXIT
```

## HR6

Condition:

```text
IF E_TOTAL >= 15
AND E1 >= 3
AND E2 >= 3
AND E3 == 4
AND E4 >= 3:
    Hard_Red = TRUE
    final_action = EXIT
```

## Design Supplement

When TDT-RM market signal is Red, HR1 is the primary exit mechanism.

If market is Red and ETF is below MA20, HR1 directly triggers EXIT.

At this point, the scoring system becomes a secondary confirmation layer.

This is intentional design, not a loophole.
