# 13 Daily Report Format

## Title

```text
YYYY/MM/DD 0052, 00830 TDT-ETF Exit V2.3.4 盤後報告
```

## Basic Fields

```text
作者: Dr. Yen
模型: TDT-ETF Exit V2.3.4-Market Integrated
資料日期: YYYY/MM/DD
產出時間: YYYY/MM/DD HH:MM
資料狀態: 盤後正式版 / 暫估版
```

## Market Status Section

```text
TDT-RM 燈號:
市場狀態:
MHS:
TCWRS:
ETI-5:
Tail Risk:
BCD:
Crash Probability:
CP 狀態:
E3_MARKET_SYSTEM_RISK:
MARKET_FLOOR: 是 / 否
MARKET_FLOOR_RED: 是 / 否
```

## 0052 Section

```text
E1:
E2:
E3:
E4:
E_TOTAL:
score_signal:
score_action:
active_floor_signals:
雙軸事件: 是 / 否
雙軸事件起始日:
Hard Red: 是 / 否
HR 觸發項目:
EVENT_RED_LOCK: 是 / 否
EVENT_RED_LOCK 起始日:
PHR_LOCK: 是 / 否
PHR_Day_Count:
SBRL_LOCK: 是 / 否
SBRL_Day_Count:
final_signal:
final_action:
```

## 00830 Section

```text
E1:
E2:
E3:
E4:
E_TOTAL:
score_signal:
score_action:
active_floor_signals:
SOX_DATA_LAG: 是 / 否
雙軸事件: 是 / 否
雙軸事件起始日:
Hard Red: 是 / 否
HR 觸發項目:
EVENT_RED_LOCK: 是 / 否
EVENT_RED_LOCK 起始日:
PHR_LOCK: 是 / 否
PHR_Day_Count:
SBRL_LOCK: 是 / 否
SBRL_Day_Count:
final_signal:
final_action:
```

## Today's Action

```text
0052:
00830:
```

## Reduction Priority

1. Reduce the ETF with higher final_signal first.
2. If final_signal is the same, reduce the one with more Hard Red or lock triggers first.
3. If still the same, reduce the one with higher E1 + E4 first.
4. If still the same, reduce the one with higher E2 first.
5. If only MHS and BCD are high but TCWRS and ETI-5 are low, only stop adding; do not force reduction.

## Alert Release Conditions

1. Hard Red does not trigger again.
2. PHR_LOCK has lasted at least 10 ETF trading days and satisfies PHR release conditions.
3. EVENT_RED_LOCK has met asset-specific release conditions.
4. SBRL_LOCK has met slow bear lock release conditions.
5. TDT-RM market signal has fallen to Yellow or Green.
6. TCWRS <= 45.
7. ETI-5 <= 1.

## Final Conclusion

```text
0052:
00830:
Market currently belongs to:
- High-level bull market
- High-level consolidation
- Structural weakening
- Systemic risk
```
