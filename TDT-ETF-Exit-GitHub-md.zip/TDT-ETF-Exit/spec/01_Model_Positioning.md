# 01 Model Positioning

## Metadata

Author: Dr. Yen

Model Name:
TDT-ETF Exit V2.3.4-Market Integrated

Chinese Name:
0052, 00830 ETF 大盤整合風控出場模型

English Name:
Taiwan ETF Exit Risk Control Model V2.3.4 with TDT-RM Market Layer

Version Status:
Spec Freeze Candidate / Historical Stress-Test Ready

Generated Time:
2026-05-24 15:55

Applicable Assets:
- 0052
- 00830

## Purpose

Use after market close or the following morning, based on previous trading day's official data, to determine whether 0052 and 00830 should be:

- HOLD
- STOP_ADD
- REDUCE
- HEAVY_REDUCE
- EXIT

## Core Principle

This model is an ETF risk-control and exit model.

It is not:
- A buy model
- An averaging-down model
- A short-term forecasting model

## Model Architecture

The model integrates two layers:

1. Market Layer:
   TDT-RM V5.1.3 Rev.3 Final Freeze

2. ETF Layer:
   TDT-ETF Exit V2.3.4-Market Integrated

## Responsibilities

Market Layer:
Evaluate the market risk environment.

ETF Layer:
Evaluate whether the ETF body and theme structure are damaged.

## Final Decision Principle

Final decision is not based only on the market.

Final decision is not based only on ETF price.

True danger is defined as:

```text
ETF structure breakdown
+ Theme structure failure
+ Market risk upgrade
+ Event resonance
```

## Mandatory EXIT Principle

Hard Red is the only mandatory EXIT core.

MHS, BCD, and Tail Risk must not independently trigger EXIT.

Crash Probability is only a market risk summary and does not enter the ETF exit engine.
