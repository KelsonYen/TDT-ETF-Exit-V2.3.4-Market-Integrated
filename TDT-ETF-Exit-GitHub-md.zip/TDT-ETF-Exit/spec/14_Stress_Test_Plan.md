# 14 Stress Test Plan and Version Declaration

## Stress Test Sequence

1. 2020/03 pandemic crash
2. 2022/01-2022/10 rate-hike bear market
3. 2024/07 AI stock selloff
4. 2026/05 high-level overheating and strong-bull consolidation

## Stress Test Focus

1. Whether Hard Red is too early or too late.
2. Whether HR1-HR6 produce false positives.
3. Whether EVENT_RED_LOCK is too strict or too loose.
4. Whether PHR_LOCK locks for too long.
5. Whether SBRL_LOCK can identify slow bear markets.
6. Whether score_signal and final_signal are logically consistent.
7. Whether 0052 and 00830 produce reasonable differences because their themes are different.
8. Whether false negatives occur where EXIT should happen but does not happen.
9. Whether false positives occur where EXIT should not happen but does happen.

## Final Version Conclusion

TDT-ETF Exit V2.3.4 is the complete version currently usable for stress testing.

This version is not Final Freeze.

This version is not Production Final.

This version is:

```text
Spec Freeze Candidate / Historical Stress-Test Ready
```

## Follow-up Rules

1. Do not add new rules before stress testing.
2. Do not temporarily change parameters because of subjective market views.
3. Only if historical stress testing identifies clear false positives, false negatives, or non-executable situations may the model enter the next revision.
4. If all four stress tests show no major issue, V2.3.4 can be upgraded to Final Freeze Candidate.
