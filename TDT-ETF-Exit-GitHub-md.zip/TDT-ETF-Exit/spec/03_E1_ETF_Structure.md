# 03 E1 ETF Structure

## Score Range

```text
0-4
```

## Purpose

Evaluate whether the ETF body shows trend structure damage.

## Scoring Rules

```text
IF ETF_Close > ETF_MA20 AND ETF_Close > ETF_MA60:
    E1 = 0
```

```text
IF ETF_Close < ETF_MA20:
    E1 = 1
```

```text
IF ETF_Close below ETF_MA20 for 2 consecutive trading days:
    E1 = 2
```

```text
IF ETF_Close below ETF_MA20 for 3 or more consecutive trading days:
    E1 = 3
```

```text
IF ETF_Close < ETF_MA60:
    E1 = 4
```

```text
IF ETF_MA20 < ETF_MA60:
    E1 = 4
```

```text
IF ETF_Close < ETF_MA60 AND ETF_MA20 is declining:
    E1 = 4
```

## Multiple Condition Rule

If multiple conditions are true, use the highest score only.

Do not accumulate.

## MA20 Declining Definition

```text
IF MA20_today < MA20_5_trading_days_ago:
    MA20_declining = TRUE
```

Rules:
1. Use numeric comparison only.
2. Do not use visual inspection.
3. If data is insufficient, do not use this condition.

## Consecutive Below-MA20 Count Reset Rule

```text
IF ETF_Close >= ETF_MA20:
    below_MA20_count = 0
```

```text
IF next trading day ETF_Close < ETF_MA20:
    restart count
    E1 = 1
```

```text
IF below_MA20_count == 2:
    E1 = 2
```

```text
IF below_MA20_count >= 3:
    E1 = 3
```

```text
IF ETF_Close < ETF_MA60:
    E1 = 4
```

When ETF closes below MA60, E1 is directly set to 4 and is not limited by MA20 consecutive count.

## Design Note

The following conditions all equal maximum E1 risk level:
- ETF closes below MA60
- ETF MA20 crosses below MA60
- ETF closes below MA60 and MA20 continues declining

All are assigned:

```text
E1 = 4
```

The score is the same, but severity may be annotated for review and backtesting.
