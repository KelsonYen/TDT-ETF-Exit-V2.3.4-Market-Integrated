# 06 E4 Theme Structure Breakdown

## Score Range

```text
0-4
```

## Purpose

Evaluate whether the ETF corresponding theme structure is breaking down.

## Formula

```text
E4 = base_score + bonus_score
E4 = min(E4, 4)
```

## Base Score

Use highest base score only.

Do not accumulate base conditions.

```text
IF theme_close < theme_MA20:
    base_score = 1
```

```text
IF theme_close below theme_MA20 for 2 consecutive days:
    base_score = 2
```

```text
IF theme_close < theme_MA60:
    base_score = 3
```

```text
IF theme_MA20 < theme_MA60:
    base_score = 4
```

## Bonus Score

```text
bonus_score = 0
```

```text
IF theme_long_black_candle == TRUE OR theme_explosive_black_candle == TRUE:
    bonus_score += 1
```

```text
IF majority_components_below_MA20 == TRUE:
    component_bonus = 1
```

```text
IF majority_components_below_MA60 == TRUE:
    component_bonus = 2
```

Majority below MA20 and majority below MA60 cannot both be accumulated.

Use the higher component bonus only.

```text
bonus_score += component_bonus
```

Final cap:

```text
E4 = min(base_score + bonus_score, 4)
```

## 0052 Theme Structure

Theme:
TSMC + Taiwan technology leaders.

Fixed list:
- 2330 TSMC
- 2454 MediaTek
- 2317 Hon Hai
- 2382 Quanta
- 2308 Delta Electronics
- 3034 Novatek

### 0052 Majority Below MA20

```text
IF count(technology_leaders_below_MA20) >= 4 of 6:
    majority_components_below_MA20 = TRUE
```

### 0052 Majority Below MA60

```text
IF count(technology_leaders_below_MA60) >= 4 of 6:
    majority_components_below_MA60 = TRUE
```

## 00830 Theme Structure

Theme:
SOX + US semiconductor leaders.

Fixed list:
- NVDA
- AMD
- AVGO
- QCOM
- MU
- INTC
- AMAT
- LRCX

### 00830 Majority Below MA20

```text
IF count(us_semiconductor_leaders_below_MA20) >= 5 of 8:
    majority_components_below_MA20 = TRUE
```

### 00830 Majority Below MA60

```text
IF count(us_semiconductor_leaders_below_MA60) >= 5 of 8:
    majority_components_below_MA60 = TRUE
```

## Theme Long Black Candle and Explosive Black Candle Definitions

### 0052

Theme:
TSMC + Taiwan technology leaders.

TSMC theme long black candle:

```text
IF TSMC_daily_return <= -2.5%
AND TSMC_black_body_size >= TSMC_daily_range * 0.55:
    theme_long_black_candle = TRUE
```

TSMC explosive black candle:

```text
IF TSMC_daily_return <= -3%
AND TSMC_volume >= TSMC_20_day_avg_volume * 1.80
AND TSMC_black_body_size >= TSMC_daily_range * 0.60:
    theme_explosive_black_candle = TRUE
```

### 00830

Theme:
SOX + US semiconductor leaders.

SOX does not use volume condition.

SOX theme long black candle:

```text
IF SOX_daily_return <= -2.5%
AND SOX_close <= SOX_low + 0.40 * (SOX_high - SOX_low):
    theme_long_black_candle = TRUE
```

SOX theme explosive black candle substitute condition:

All conditions required:

```text
IF SOX_daily_return <= -3%
AND count(us_semiconductor_leaders_close_black) >= 5 of 8
AND count(us_semiconductor_leaders_daily_return <= -3%) >= 4 of 8:
    theme_explosive_black_candle = TRUE
```

## SOX_DATA_LAG Rule

If latest SOX closing data is not available:

```text
E4 = previous_valid_E4
SOX_DATA_LAG = TRUE
```

Rules during SOX_DATA_LAG:

1. 00830 E4 uses the previous valid evaluation value.
2. Data status is marked as `SOX_DATA_LAG`.
3. EVENT_RED_LOCK must not be released.
4. E4 must not be reduced; it can only retain the previous value.
5. E4 must not be subjectively increased because of CPI, Fed, earnings, or news events.
6. If later SOX data triggers a higher score, the day must be backfilled and corrected.
