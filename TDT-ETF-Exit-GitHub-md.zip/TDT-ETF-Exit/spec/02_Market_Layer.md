# 02 Market Layer

## Market Layer Inputs

### TDT-RM Signal

Allowed values:
- Green
- Yellow
- Yellow Enhanced
- Orange
- Red

### MHS

Market Heat Score.

Purpose:
Measure whether the market is overheating.

High MHS means:
- Price chasing
- Expanded turnover
- Rich valuation
- Crowded themes

Rule:
MHS high does not equal market crash.

### TCWRS

Taiwan Crash Warning Risk Score.

Purpose:
Evaluate structural risk in the Taiwan equity market.

Observed factors include:
- Price breakdown
- Foreign investor selling
- TWD depreciation
- Margin leverage not declining
- Breadth deterioration
- Mainstream stock failure

### ETI-5

Exit Trigger Index 5.

Purpose:
Confirm whether risk has landed.

ETI-5 is not temperature.

ETI-5 is damage count.

Higher ETI-5 means risk moves from potential risk to realized risk.

### Tail Risk

Purpose:
Measure extreme pressure.

Includes:
- Hedging pressure increase
- Equity-FX resonance
- External market selloff
- Liquidity deterioration

Rule:
Tail Risk alone cannot upgrade the market to Red.

### BCD

Breadth Concentration Divergence.

Purpose:
Evaluate whether an uptrend is false strength.

BCD is meaningful only when:
- Index is rising
- Index is at high level or making new highs

### Crash Probability

Crash Probability is a conditional market risk summary.

It is not an ETF exit trigger.

## Crash Probability Formula

```text
CP = TCWRS * 0.40 + ETI5 * 20 * 0.30 + TailRisk * 0.20 + BCD * 0.10
```

## CP Classification

```text
0-30   = Low
31-55  = Medium
56-75  = High
76-100 = Extreme
```

## CP Usage Rules

1. CP is only a market risk summary field.
2. CP does not enter E1, E2, E3, or E4 scoring.
3. CP cannot lift E3.
4. CP cannot independently upgrade signal.
5. CP cannot independently trigger Hard Red.
6. CP cannot independently trigger EXIT.
7. If historical test data is insufficient, CP may be marked as `DATA_INSUFFICIENT`; this does not affect `score_signal` or `final_signal`.
