# 09 PHR_LOCK

## Full Name

Post-Hard-Red Recovery Lock

## Purpose

Lock the recovery period after Hard Red resolves, preventing risk from being lowered too quickly immediately after Red signal release.

## Definitions

### HR_D0

Hard Red trigger day.

### HR_RESOLVED_D0

First trading day on which all Hard Red conditions are no longer active.

### PHR_D1

The next ETF trading day after HR_RESOLVED_D0.

PHR_LOCK starts from PHR_D1.

### Minimum Lock Period

At least 10 ETF trading days.

## Lock Floor

```text
IF PHR_LOCK == TRUE:
    final_signal >= ORANGE_ENHANCED
```

## PHR_LOCK Release Conditions

All conditions required:

1. At least 10 ETF trading days have passed since PHR_D1.
2. ETF closes above MA20 for 3 consecutive evaluable trading days.
3. Theme closes above MA20 for 3 consecutive evaluable trading days.
4. TDT-RM market signal falls to Yellow or Green.
5. TCWRS <= 45.
6. ETI-5 <= 1.
7. No new Hard Red during the period.
8. If EVENT_RED_LOCK previously existed, that lock must also have been released.

## PHR_LOCK Reset Rules

```text
IF any Hard Red occurs during PHR_LOCK:
    reset PHR counter to zero
    define new HR_D0
    wait until new Hard Red conditions are all resolved
    define new HR_RESOLVED_D0
    define new PHR_D1 as next ETF trading day after HR_RESOLVED_D0
    restart PHR_LOCK
```

Old PHR count must not be reused.
