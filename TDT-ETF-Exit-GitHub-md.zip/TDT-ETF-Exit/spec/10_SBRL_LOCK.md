# 10 SBRL_LOCK

## Full Name

Slow Bear Regime Lock

## Purpose

Handle slow bear market structures and prevent the model from missing gradual downside regimes where the market does not crash quickly but keeps drifting lower.

## Activation Conditions

All conditions required:

```text
IF ETF_Close < ETF_MA20 for 10 consecutive trading days
AND Theme_Close < Theme_MA20 for 10 consecutive trading days
AND (ETF_Close < ETF_MA60 OR Theme_Close < Theme_MA60)
AND TCWRS >= 55 for 5 consecutive trading days
AND ETF and Theme did not both recover MA20 for 2 consecutive days during the period:
    SBRL_LOCK = TRUE
```

## Count Reset Rules

```text
IF ETF_Close >= ETF_MA20:
    ETF_below_MA20_10_day_count = 0
```

```text
IF Theme_Close >= Theme_MA20:
    Theme_below_MA20_10_day_count = 0
```

```text
IF TCWRS < 55:
    TCWRS_above_55_5_day_count = 0
```

```text
IF ETF_Close >= ETF_MA60 AND Theme_Close >= Theme_MA60:
    MA60_break_condition = FALSE
```

If MA60 break condition becomes false, but MA20 and TCWRS conditions remain active, SBRL_LOCK must not newly activate.

The system must wait for the MA60 condition to become true again.

## Release Conditions

All conditions required:

1. ETF closes above MA20 for 3 consecutive trading days.
2. Theme closes above MA20 for 3 consecutive trading days.
3. If SBRL was activated because of MA60 break, ETF and theme both must recover MA60, or at least the axis that broke MA60 must recover MA60.
4. TCWRS is below 45 for 3 consecutive trading days.
5. TDT-RM market signal falls to Yellow or Green.
6. Only after all above conditions are true can SBRL_LOCK be released.

## PHR_LOCK and SBRL_LOCK Simultaneous Activation

1. If PHR_LOCK and SBRL_LOCK are both active, PHR_LOCK is the stricter lock.
2. During PHR_LOCK, final_signal must not be lower than Orange Enhanced.
3. During SBRL_LOCK, final_signal must not be lower than Orange.
4. If both exist, final_signal must not be lower than Orange Enhanced.
5. After PHR_LOCK is released, if SBRL_LOCK remains active, final_signal must still not be lower than Orange.
