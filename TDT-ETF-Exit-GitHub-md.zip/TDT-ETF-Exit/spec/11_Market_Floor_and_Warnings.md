# 11 Market Floor and Warning Rules

## MARKET_FLOOR

```text
IF TDT_RM_signal == ORANGE:
    ETF_final_signal >= YELLOW
```

When the market is Orange, ETF final_signal must not be lower than Yellow.

## MARKET_FLOOR_RED

```text
IF TDT_RM_signal == RED:
    ETF_final_signal >= ORANGE
```

When the market is Red, ETF final_signal must not be lower than Orange.

## MHS / BCD / Tail Risk Warning Rules

### Rule 1

If MHS, BCD, or Tail Risk triggers alone:

```text
final_signal <= YELLOW_ENHANCED
```

They can raise signal only up to Yellow Enhanced.

### Rule 2

```text
IF MHS >= 86
AND BCD >= 61
AND TCWRS < 41
AND ETI5 <= 1:
    final_signal >= YELLOW
    final_signal <= YELLOW_ENHANCED
    final_action must not be REDUCE
```

### Rule 3

```text
IF MHS >= 86
AND BCD >= 61
AND TCWRS >= 41
AND ETI5 <= 1:
    final_signal >= YELLOW_ENHANCED
    final_signal <= YELLOW_ENHANCED
```

### Rule 4

```text
IF MHS >= 86
AND BCD >= 61
AND TCWRS >= 41
AND ETI5 >= 2:
    final_signal <= ORANGE
```

### Rule 5

The above warning situations must not upgrade to:
- Orange Enhanced
- Red
- EXIT

### Rule 6

To upgrade to Orange Enhanced or Red, the trigger must come from:
- ETF score
- Event lock
- Hard Red
